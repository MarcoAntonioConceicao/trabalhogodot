using Godot;
using System;

public partial class Area2D : Godot.Area2D
{
	public int diamantes = 1;

	// Chamado quando o nó entra na árvore da cena pela primeira vez.
	public override void _Ready()
	{
	}

	// Chamado a cada quadro. 'delta' é o tempo decorrido desde o último quadro.
	public override void _Process(double delta)
	{
		 // Passa o valor atualizado de 'diamantes'
	}

	public void _on_body_entered(Node2D body)
	{
		if (body is CharacterBody2D)
		{
			diamantes--;
			Visible = false;
			QueueFree(); // Desconecta e remove o nó da cena
		checadiamante(diamantes);
		}
	}

	public void checadiamante(int diamantes)
	{
		if (diamantes == 0)
		{
			GD.Print("Coletou um diamante!");
		}
	}
}








