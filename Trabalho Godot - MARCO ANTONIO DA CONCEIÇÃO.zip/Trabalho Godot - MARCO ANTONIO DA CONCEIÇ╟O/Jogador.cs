using Godot;
using System;

public partial class Jogador : CharacterBody2D
{
	private Vector2 velocity;
	private Vector2 direction;
	public Vector2 savePoint;
	public const float Speed = 300.0f; 
	private bool isFacingRight = true;
public const int MaxJumps = 2; // Número máximo de pulos permitidos
	private int jumpCount = 0; // Contador de pulos realizados
	 private float jumpForce = 400.0f; // Força do salto
	// Get the gravity from the project settings to be synced with RigidBody nodes.
	public float gravity = ProjectSettings.GetSetting("physics/2d/default_gravity").AsSingle();

	private AnimatedSprite2D animate;
	private Vector2 StartPosition;
	public override void _Ready() {
		animate = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
	 StartPosition = GlobalPosition;
	savePoint = GlobalPosition;
	} //fim do ready

	public override void _PhysicsProcess(double delta)
	{
		//inercia inicial
		velocity = Velocity;

		if (direction.X < 0 && !isFacingRight)
		{
			FlipSprite();
		}
		else if (direction.X > 0 && isFacingRight)
		{
			FlipSprite();
		}
		
		// Add the gravity.
		if (!IsOnFloor())
			velocity.Y += gravity * (float)delta;
// Handle Jump.
		if (Input.IsActionJustPressed("ui_accept"))
		{
	if (IsOnFloor())
			{
				velocity.Y = -jumpForce * Input.GetActionStrength("ui_accept");
				jumpCount = 1; // Primeiro pulo
			}
			else if (jumpCount < MaxJumps)
			{
				velocity.Y = -jumpForce * Input.GetActionStrength("ui_accept");
				jumpCount++; // Pulo adicional
			}
		}
		// Get the input direction and handle the movement/deceleration.
		// As good practice, you should replace UI actions with custom gameplay actions.
		direction = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");
		if (direction != Vector2.Zero)
		{
			velocity.X = direction.X * Speed;
		}
		else
		{
			//velocity.X = 0;
			velocity.X = Mathf.MoveToward(Velocity.X, 0, Speed*(float)(2*delta));
		}

		Velocity = velocity;
		MoveAndSlide();

		Animation(velocity);

	// Verificar se o personagem caiu abaixo da posição desejada
		if (GlobalPosition.Y > 600)
		{
			// Reposicionar o personagem no início
			GlobalPosition = savePoint;

			// Reiniciar contadores e velocidades
			velocity = Vector2.Zero;
			jumpCount = 0;
		}
	if (GlobalPosition.X >= 1641)
{
	savePoint = new Vector2(1641, 179);
}

	} //fim do process

	private void Animation(Vector2 velocity) {
		if (!IsOnFloor()){
			animate.Play("jump");
		} else {
			if (velocity.X != 0) {
				animate.Play("run");
			} else {
				animate.Play("idle");
			}
		}
	}
public void voltarinicio() {
GlobalPosition = savePoint;
}
private void FlipSprite()
	{
		isFacingRight = !isFacingRight;
		// Inverter a escala horizontal da sprite
		animate.Scale = new Vector2(isFacingRight ? 1 : -1, 1);
	}
} //fim da classe
